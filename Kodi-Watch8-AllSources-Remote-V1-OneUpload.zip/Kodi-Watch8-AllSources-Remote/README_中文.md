# Kodi Watch8 All Sources Remote V1

独立 Wear OS 应用，复用 V7 圆形镂空媒体面板。无需手机端。

## 使用
1. Kodi → 设置 → 服务 → 控制：允许通过 HTTP 远程控制，设置端口（默认 8080）、用户名与密码。使用可信局域网，不向公网开放 HTTP 端口。
2. 在 Kodi 视频、音乐、图片或文件管理器添加媒体源。DLNA/UPnP 请先在 Kodi 中启用 UPnP 支持并添加服务器为源。
3. 手表和 Kodi 处于可互通的局域网，手表输入 Kodi 的 IP、端口与 HTTP 凭据。SMB 等共享凭据由 Kodi 管理。
4. 点击文件夹进入，点击文件调用 Player.Open，成功后显示控制面板。左侧返回列表，底部切换方向/媒体，外围快进退 30 秒、字幕、音量、静音、设置。
5. 文件来源不限制协议；实际可列出范围由 Kodi JSON-RPC 与源权限决定。非媒体文件可能不可播放；部分图片或音频不支持字幕/跳转等控制。插件内容和媒体库不是此版专用浏览功能。

## GitHub 一次上传构建
新建仓库 Kodi-Watch8-AllSources-Remote，将完整 ZIP 原样上传到仓库根目录，再新建 .github/workflows/build-apk.yml（使用另附工作流）。Actions 构建完成后下载 Kodi-Watch8-AllSources-Remote-APK 工件。若解压上传完整工程，应调整工作流解压步骤。

## 测试状态
几何单元测试已通过；没有真实 Kodi、Watch8 或本地 Android SDK，因此未执行 Android 编译和真机联调。
