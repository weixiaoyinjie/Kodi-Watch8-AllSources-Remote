package com.kodiwatch.remote;
import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import android.util.Base64;
import org.json.*;

final class KodiRpc {
    static final class Failure extends IOException { Failure(String m){super(m);} }
    private final URL url;
    private final String auth;
    private int id;
    KodiRpc(String host,int port,String user,String password){
        if(host.isEmpty()||!host.matches("[A-Za-z0-9.:-]+")||port<1||port>65535)throw new IllegalArgumentException("host/port");
        try{url=new URL("http",host,port,"/jsonrpc");}catch(MalformedURLException e){throw new IllegalArgumentException(e);}
        auth=user.isEmpty()&&password.isEmpty()?null:"Basic "+Base64.encodeToString((user+":"+password).getBytes(StandardCharsets.UTF_8),Base64.NO_WRAP);
    }
    JSONObject object(String method,JSONObject params)throws Exception{return (JSONObject)call(method,params);}
    Object call(String method,JSONObject params)throws Exception{
        HttpURLConnection c=(HttpURLConnection)url.openConnection();
        try{
            c.setConnectTimeout(4000);c.setReadTimeout(8000);c.setInstanceFollowRedirects(false);c.setRequestMethod("POST");c.setDoOutput(true);
            c.setRequestProperty("Content-Type","application/json; charset=UTF-8");if(auth!=null)c.setRequestProperty("Authorization",auth);
            int requestId=++id;byte[] data=new JSONObject().put("jsonrpc","2.0").put("id",requestId).put("method",method).put("params",params).toString().getBytes(StandardCharsets.UTF_8);
            c.setFixedLengthStreamingMode(data.length);try(OutputStream out=c.getOutputStream()){out.write(data);}
            int code=c.getResponseCode();if(code==401||code==403)throw new Failure("Kodi HTTP 用户名或密码错误");if(code!=200)throw new Failure("Kodi HTTP 错误 "+code);
            ByteArrayOutputStream bytes=new ByteArrayOutputStream();try(InputStream in=c.getInputStream()){byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1){if(bytes.size()+n>8*1024*1024)throw new Failure("目录过大，请细分共享文件夹");bytes.write(buf,0,n);}}
            JSONObject res=new JSONObject(bytes.toString("UTF-8"));if(res.optInt("id",-1)!=requestId)throw new Failure("Kodi 返回异常");if(res.has("error"))throw new Failure("Kodi 操作失败 ("+res.getJSONObject("error").optInt("code")+")");if(!res.has("result"))throw new Failure("Kodi 无有效响应");return res.get("result");
        }finally{c.disconnect();}
    }
}
