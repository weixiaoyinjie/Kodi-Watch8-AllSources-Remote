package com.kodiwatch.remote;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.text.TextUtils;
import android.view.*;
import android.widget.*;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;

public final class MainActivity extends Activity {
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private SharedPreferences prefs;
    private KodiRpc rpc;
    private boolean busy, panelVisible, lastError;
    private RoundPanelView panel;
    private final ArrayList<Page> history=new ArrayList<>();
    private ArrayList<Entry> playingFiles=new ArrayList<>();
    private int playingIndex=-1;
    private ListView list;
    private TextView status;
    private static final class Entry {
        final String label,file,media; final boolean dir;
        Entry(String l,String f,String m,boolean d){label=l;file=f;media=m;dir=d;}
    }
    private static final class Page {
        final String title,path,media; final ArrayList<Entry> entries;
        int position, offset;
        Page(String t,String p,String m,ArrayList<Entry> e){title=t;path=p;media=m;entries=e;}
    }
    private static JSONObject obj(Object... a){
        JSONObject j=new JSONObject();try{for(int i=0;i<a.length;i+=2)j.put((String)a[i],a[i+1]);}catch(JSONException e){throw new IllegalArgumentException(e);}return j;
    }
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        prefs=getSharedPreferences("kodi_connection",MODE_PRIVATE);
        readConfig();showBrowser();if(rpc==null)showSettings();else loadSources();
    }
    @Override public void onDestroy(){worker.shutdownNow();super.onDestroy();}
    private void readConfig(){String h=prefs.getString("host","");rpc=h.isEmpty()?null:new KodiRpc(h,prefs.getInt("port",8080),prefs.getString("user",""),prefs.getString("password",""));}
    private interface Task<T>{T run(KodiRpc c)throws Exception;}
    private interface Done<T>{void done(T result);}
    private <T> void request(Task<T> action,Done<T> done){
        if(busy)return;if(rpc==null){showSettings();return;}
        busy=true;if(status!=null&&!panelVisible)status.setText("读取中…");
        final KodiRpc conn=rpc;
        worker.execute(()->{try{T result=action.run(conn);runOnUiThread(()->{if(isFinishing()||isDestroyed())return;busy=false;lastError=false;if(panel!=null)panel.invalidate();if(status!=null&&!panelVisible)status.setText("");done.done(result);});}
        catch(Exception ex){runOnUiThread(()->{if(isFinishing()||isDestroyed())return;busy=false;lastError=true;if(panel!=null)panel.invalidate();String msg=ex instanceof KodiRpc.Failure?ex.getMessage():"连接失败，请检查 Kodi 和 Wi-Fi";if(status!=null&&!panelVisible)status.setText(msg);Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();});}});
    }
    private Page current(){return history.isEmpty()?null:history.get(history.size()-1);}
    private void rememberScroll(){Page p=current();if(p!=null&&list!=null&&!panelVisible){p.position=list.getFirstVisiblePosition();p.offset=list.getChildCount()>0?list.getChildAt(0).getTop():0;}}
    private TextView text(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(size);t.setGravity(Gravity.CENTER);return t;}
    private TextView button(String s,View.OnClickListener click){TextView t=text(s,13);GradientDrawable bg=new GradientDrawable();bg.setColor(Color.BLACK);bg.setStroke(dp(1),0xff444444);bg.setCornerRadius(dp(18));t.setBackground(bg);t.setOnClickListener(click);t.setMinHeight(dp(32));return t;}
    private void showBrowser(){
        panelVisible=false;panel=null;Page p=current();
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.BLACK);
        int w=getResources().getDisplayMetrics().widthPixels,h=getResources().getDisplayMetrics().heightPixels;
        root.setPadding(Math.round(w*.12f),Math.round(h*.12f),Math.round(w*.12f),Math.round(h*.10f));
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        TextView back=button("‹",v->goBack());back.setContentDescription("返回上一级");top.addView(back,new LinearLayout.LayoutParams(dp(32),dp(32)));
        TextView title=text(p==null?"Kodi 媒体源":p.title,15);title.setSingleLine(true);title.setEllipsize(TextUtils.TruncateAt.END);title.setTypeface(Typeface.DEFAULT_BOLD);top.addView(title,new LinearLayout.LayoutParams(0,dp(32),1));
        TextView gear=button("⚙",v->showSettings());gear.setContentDescription("连接设置");top.addView(gear,new LinearLayout.LayoutParams(dp(32),dp(32)));root.addView(top);
        list=new ListView(this);list.setDivider(new android.graphics.drawable.ColorDrawable(0xff333333));list.setDividerHeight(dp(1));list.setCacheColorHint(Color.BLACK);list.setVerticalScrollBarEnabled(false);
        ArrayList<Entry> items=p==null?new ArrayList<>():p.entries;
        list.setAdapter(new BaseAdapter(){public int getCount(){return items.size();}public Object getItem(int i){return items.get(i);}public long getItemId(int i){return i;}public View getView(int i,View old,android.view.ViewGroup parent){Entry e=items.get(i);TextView t=old instanceof TextView?(TextView)old:text("",15);t.setGravity(Gravity.CENTER_VERTICAL|Gravity.START);t.setText((e.dir?"▱  ":"▷  ")+e.label);t.setMaxLines(2);t.setEllipsize(TextUtils.TruncateAt.END);t.setMinHeight(dp(40));t.setPadding(dp(4),dp(5),dp(4),dp(5));return t;}});
        list.setOnItemClickListener((a,v,i,id)->{if(busy)return;Entry e=items.get(i);rememberScroll();if(e.dir)loadDirectory(e);else play(e,items);});root.addView(list,new LinearLayout.LayoutParams(-1,0,1));
        if(p!=null)list.setSelectionFromTop(p.position,p.offset);
        status=text(p==null?"连接 Kodi 后读取媒体源":items.isEmpty()?"没有媒体文件":"",11);status.setMaxLines(2);root.addView(status,new LinearLayout.LayoutParams(-1,-2));
        LinearLayout bottom=new LinearLayout(this);bottom.addView(button("刷新",v->{if(busy)return;rememberScroll();Page q=current();if(q==null||q.path==null)loadSources();else reload(q);}),new LinearLayout.LayoutParams(0,dp(32),1));
        bottom.addView(button("控制",v->{if(!busy){rememberScroll();showPanel();}}),new LinearLayout.LayoutParams(0,dp(32),1));root.addView(bottom);
        setContentView(root);
    }
    private void showPanel(){panelVisible=true;list=null;status=null;panel=new RoundPanelView(true);panel.setBackgroundColor(Color.BLACK);setContentView(panel);}
    private void goBack(){if(busy)return;if(panelVisible){showBrowser();return;}if(history.size()>1){history.remove(history.size()-1);showBrowser();}else finish();}
    @Override public void onBackPressed(){goBack();}
    private static String safeLabel(String label,String path){
        if(!label.isEmpty()&&!label.contains("://"))return label;
        String p=path.replaceAll("/+$","");int i=p.lastIndexOf('/');String name=i>=0&&i+1<p.length()?p.substring(i+1):"媒体源";
        return name.contains("@")?"网络媒体源":name;
    }
    private static String mediaLabel(String m){switch(m){case "video":return "视频";case "music":return "音乐";case "pictures":return "图片";default:return "文件";}}
    private void loadSources(){request(c->{
        ArrayList<Entry> a=new ArrayList<>();HashSet<String> seen=new HashSet<>();
        for(String m:new String[]{"video","music","pictures","files"}){
            JSONArray arr=c.object("Files.GetSources",obj("media",m)).optJSONArray("sources");if(arr==null)continue;
            for(int i=0;i<arr.length();i++){JSONObject j=arr.getJSONObject(i);String file=j.optString("file");
                if(!file.isEmpty()&&seen.add(m+"\n"+file))a.add(new Entry(safeLabel(j.optString("label"),file)+" · "+mediaLabel(m),file,m,true));}
        }return a;
    },a->{history.clear();history.add(new Page("Kodi 媒体源",null,null,a));showBrowser();if(a.isEmpty())status.setText("请先在 Kodi 添加媒体源");});}
    private ArrayList<Entry> directory(KodiRpc c,String path,String media)throws Exception{
        JSONArray a=c.object("Files.GetDirectory",obj("directory",path,"media",media,"sort",obj("method","label","order","ascending"))).optJSONArray("files");ArrayList<Entry> out=new ArrayList<>();
        if(a!=null)for(int i=0;i<a.length();i++){JSONObject j=a.getJSONObject(i);String f=j.optString("file");if(!f.isEmpty())out.add(new Entry(safeLabel(j.optString("label"),f),f,media,"directory".equals(j.optString("filetype"))));}
        out.sort(Comparator.comparing((Entry e)->!e.dir));return out;
    }
    private void loadDirectory(Entry e){request(c->directory(c,e.file,e.media),a->{history.add(new Page(e.label,e.file,e.media,a));showBrowser();});}
    private void reload(Page p){request(c->directory(c,p.path,p.media),a->{Page q=new Page(p.title,p.path,p.media,a);q.position=Math.min(p.position,Math.max(0,a.size()-1));q.offset=p.offset;history.set(history.size()-1,q);showBrowser();});}
    private void play(Entry e,ArrayList<Entry> entries){ArrayList<Entry> files=new ArrayList<>();for(Entry x:entries)if(!x.dir)files.add(x);int idx=files.indexOf(e);request(c->c.call("Player.Open",obj("item",obj("file",e.file))),r->{playingFiles=files;playingIndex=idx;showPanel();});}
    private int active(KodiRpc c)throws Exception{JSONArray a=(JSONArray)c.call("Player.GetActivePlayers",obj());int audio=-1,picture=-1;for(int i=0;i<a.length();i++){JSONObject j=a.getJSONObject(i);if("video".equals(j.optString("type")))return j.getInt("playerid");if("audio".equals(j.optString("type")))audio=j.getInt("playerid");if("picture".equals(j.optString("type")))picture=j.getInt("playerid");}if(audio>=0)return audio;if(picture>=0)return picture;throw new KodiRpc.Failure("Kodi 当前没有播放媒体");}
    private void command(String m,JSONObject p){request(c->c.call(m,p),r->{});}
    private void playerCommand(String m,JSONObject p){request(c->{p.put("playerid",active(c));return c.call(m,p);},r->{});}
    private void skip(int delta){if(playingIndex>=0){int next=playingIndex+delta;if(next<0||next>=playingFiles.size()){Toast.makeText(this,"已到文件夹边界",Toast.LENGTH_SHORT).show();return;}Entry e=playingFiles.get(next);request(c->c.call("Player.Open",obj("item",obj("file",e.file))),r->playingIndex=next);}else playerCommand("Player.GoTo",obj("to",delta>0?"next":"previous"));}
    private EditText field(String hint,String value,int type){EditText e=new EditText(this);e.setSingleLine();e.setHint(hint);e.setText(value);e.setTextColor(Color.WHITE);e.setTextSize(14);e.setInputType(type);return e;}
    private void showSettings(){if(busy)return;LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(14),0,dp(14),dp(8));
        EditText host=field("Kodi IP / 主机名",prefs.getString("host",""),1);EditText port=field("HTTP 端口",String.valueOf(prefs.getInt("port",8080)),2);EditText user=field("HTTP 用户名",prefs.getString("user",""),1);EditText pass=field("HTTP 密码",prefs.getString("password",""),129);
        box.addView(host);box.addView(port);box.addView(user);box.addView(pass);ScrollView scroll=new ScrollView(this);scroll.addView(box);
        AlertDialog d=new AlertDialog.Builder(this).setTitle("Kodi 连接").setView(scroll).setNegativeButton("取消",null).setPositiveButton("保存并连接",null).create();d.setOnShowListener(v->d.getButton(-1).setOnClickListener(b->{String h=host.getText().toString().trim();int p;try{p=Integer.parseInt(port.getText().toString().trim());new KodiRpc(h,p,user.getText().toString(),pass.getText().toString());}catch(Exception ex){Toast.makeText(this,"请输入有效主机和端口",Toast.LENGTH_SHORT).show();return;}prefs.edit().putString("host",h).putInt("port",p).putString("user",user.getText().toString()).putString("password",pass.getText().toString()).apply();readConfig();playingFiles.clear();playingIndex=-1;history.clear();d.dismiss();showBrowser();loadSources();}));d.show();
    }
    private final class RoundPanelView extends View {
        private static final int POWER=1, VOL_DOWN=2, VOL_UP=3,
                BOTTOM_LEFT=4, BOTTOM_MIDDLE=5, BOTTOM_RIGHT=6,
                OK=7, UP=8, DOWN=9, LEFT=10, RIGHT=11,
                REWIND=12, FORWARD=13, STATUS=15,
                YOUTUBE=16, NETFLIX=17;
        private final boolean media;
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF bounds=new RectF();
        private boolean navigationMode;
        private int pressed, startTarget;
        private float startX,startY;
        private RoundPanelGeometry geometry;
        private final Path triangle=new Path();
        private static final int INK=0xfff2f2f2, OUTLINE=0xff444444, TOUCH=0xff161616;
        // Slots follow the screen circumference, clockwise from upper left.
        private final int[] slots;
        private int geometryWidth=-1,geometryHeight=-1;

        RoundPanelView(boolean forMedia){
            super(MainActivity.this);
            media=forMedia;
            slots=media?new int[]{POWER,STATUS,BOTTOM_MIDDLE,BOTTOM_RIGHT,FORWARD,REWIND,
                    VOL_DOWN,VOL_UP,BOTTOM_LEFT}:new int[]{POWER,STATUS,NETFLIX,YOUTUBE,BOTTOM_MIDDLE,BOTTOM_LEFT,
                    VOL_DOWN,VOL_UP,BOTTOM_RIGHT};
            setContentDescription("Kodi 控制面板：中央确定，上方播放暂停，下方停止，左右切换文件，外围设置及其他操作");
            setClickable(true);
        }

        private void computeGeometry(){
            int w=getWidth(),h=getHeight();
            if(geometry==null||w!=geometryWidth||h!=geometryHeight){
                geometryWidth=w;geometryHeight=h;
                geometry=new RoundPanelGeometry(w,h,Math.max(dp(2),1),getResources().getDisplayMetrics().density*.65f);
            }
        }

        @Override protected void onDraw(Canvas c){
            super.onDraw(c);
            computeGeometry();
            RoundPanelGeometry g=geometry;
            if(g.wheel<=0)return;
            float cx=g.cx,cy=g.cy,w=g.wheel;
            // Black canvas; only the active sector gets a neutral gray highlight.
            paint.setStyle(Paint.Style.FILL);
            if(pressed>=UP && pressed<=RIGHT){
                int angle=pressed==RIGHT?-45:pressed==DOWN?45:pressed==LEFT?135:225;
                paint.setColor(TOUCH);
                bounds.set(cx-w,cy-w,cx+w,cy+w);
                c.drawArc(bounds,angle,90,true,paint);
            }
            ringStyle();c.drawCircle(cx,cy,w,paint);
            // Deliberately omit radial separator lines: the full four sectors
            // remain tappable and the larger hollow icons show their targets.
            float offset=(w+g.ok)*.5f;
            float glyph=w*.49f;
            if(media&&!navigationMode){
                drawMediaGlyph(c,cx,cy-offset,glyph,UP);
                drawMediaGlyph(c,cx,cy+offset,glyph,DOWN);
                drawMediaGlyph(c,cx-offset,cy,glyph,LEFT);
                drawMediaGlyph(c,cx+offset,cy,glyph,RIGHT);
            }else{
                drawArrow(c,cx,cy-offset,glyph,0);
                drawArrow(c,cx,cy+offset,glyph,180);
                drawArrow(c,cx-offset,cy,glyph,270);
                drawArrow(c,cx+offset,cy,glyph,90);
            }
            paint.setStyle(Paint.Style.FILL);paint.setColor(pressed==OK?TOUCH:0xff000000);
            c.drawCircle(cx,cy,g.ok,paint);
            ringStyle();c.drawCircle(cx,cy,g.ok,paint);
            drawFittedText(c,"OK",cx,cy,g.ok*1.55f,g.ok*.77f);

            for(int i=0;i<slots.length;i++){
                int id=slots[i];float x=g.x[i],y=g.y[i],r=g.r[i];
                drawCircleKey(c,x,y,r,id);
                switch(id){
                    case POWER:drawFittedText(c,"静音",x,y,r*1.65f,r*.72f);break;
                    case STATUS:drawSettings(c,x,y,r);break;
                    case VOL_DOWN:drawVolume(c,x,y,r,false);break;
                    case VOL_UP:drawVolume(c,x,y,r,true);break;
                    case YOUTUBE:drawFittedText(c,"YT",x,y,r*1.65f,r*.83f);break;
                    case NETFLIX:drawFittedText(c,"N",x,y,r*1.65f,r*.96f);break;
                    case REWIND:drawSeek(c,x,y,r,false);break;
                    case FORWARD:drawSeek(c,x,y,r,true);break;
                    case BOTTOM_LEFT:
                        if(media)drawBack(c,x,y,r);else drawBack(c,x,y,r);
                        break;
                    case BOTTOM_MIDDLE:
                        if(media)drawFittedText(c,"字幕",x,y,r*1.65f,r*.72f);else drawMenu(c,x,y,r);
                        break;
                    case BOTTOM_RIGHT:
                        if(media)drawFittedText(c,navigationMode?"播放":"方向",x,y,r*1.65f,r*.71f);else drawHome(c,x,y,r);
                        break;
                }
            }
        }

        private void ringStyle(){
            paint.setStyle(Paint.Style.STROKE);paint.setColor(OUTLINE);
            paint.setStrokeWidth(Math.max(.75f,getResources().getDisplayMetrics().density*.55f));
            paint.setStrokeCap(Paint.Cap.ROUND);paint.setStrokeJoin(Paint.Join.ROUND);
        }
        private void inkStyle(float width){
            paint.setStyle(Paint.Style.STROKE);paint.setColor(INK);
            paint.setStrokeWidth(Math.max(.9f,width));
            paint.setStrokeCap(Paint.Cap.ROUND);paint.setStrokeJoin(Paint.Join.ROUND);
        }
        private void drawFittedText(Canvas c,String value,float x,float y,float maxWidth,float size){
            paint.setStyle(Paint.Style.FILL);paint.setColor(INK);
            paint.setTypeface(Typeface.DEFAULT_BOLD);paint.setTextSize(size);
            float measured=paint.measureText(value);
            if(measured>maxWidth)paint.setTextSize(size*maxWidth/measured);
            paint.setTextAlign(Paint.Align.CENTER);
            Paint.FontMetrics fm=paint.getFontMetrics();
            c.drawText(value,x,y-(fm.ascent+fm.descent)/2f,paint);
        }
        private void drawCircleKey(Canvas c,float x,float y,float r,int id){
            if(pressed==id){paint.setStyle(Paint.Style.FILL);paint.setColor(TOUCH);c.drawCircle(x,y,r,paint);}
            ringStyle();c.drawCircle(x,y,r,paint);
        }
        private void drawArrow(Canvas c,float x,float y,float size,float angle){
            inkStyle(size*.052f);
            c.save();c.translate(x,y);c.rotate(angle);
            triangle.reset();triangle.moveTo(0,-size*.48f);
            triangle.lineTo(size*.5f,size*.38f);triangle.lineTo(-size*.5f,size*.38f);
            triangle.close();c.drawPath(triangle,paint);c.restore();
        }
        private void drawPower(Canvas c,float x,float y,float r){
            inkStyle(r*.073f);
            // Hollow power ring: inner and outer arcs joined at the ends.
            float outer=r*.57f,inner=r*.39f;
            triangle.reset();
            triangle.arcTo(x-outer,y-outer,x+outer,y+outer,-48,276,true);
            triangle.arcTo(x-inner,y-inner,x+inner,y+inner,228,-276,false);
            triangle.close();c.drawPath(triangle,paint);
            c.drawRoundRect(x-r*.08f,y-r*.72f,x+r*.08f,y-r*.10f,r*.07f,r*.07f,paint);
        }
        private void drawSettings(Canvas c,float x,float y,float r){
            inkStyle(r*.075f);
            triangle.reset();
            for(int i=0;i<32;i++){
                double a=Math.toRadians(-90+i*360.0/32);
                float q=r*((i%4==0||i%4==3)?.45f:.60f);
                float px=x+q*(float)Math.cos(a),py=y+q*(float)Math.sin(a);
                if(i==0)triangle.moveTo(px,py);else triangle.lineTo(px,py);
            }
            triangle.close();c.drawPath(triangle,paint);c.drawCircle(x,y,r*.22f,paint);
            // Connection errors stay in settings; a white dot is the only panel indicator.
            if(lastError)c.drawCircle(x+r*.62f,y-r*.62f,r*.085f,paint);
        }
        private void drawVolume(Canvas c,float x,float y,float r,boolean plus){
            inkStyle(r*.075f);
            triangle.reset();triangle.moveTo(x-r*.68f,y-r*.19f);
            triangle.lineTo(x-r*.40f,y-r*.19f);triangle.lineTo(x-r*.10f,y-r*.43f);
            triangle.lineTo(x-r*.10f,y+r*.43f);triangle.lineTo(x-r*.40f,y+r*.19f);
            triangle.lineTo(x-r*.68f,y+r*.19f);triangle.close();c.drawPath(triangle,paint);
            c.drawLine(x+r*.12f,y,x+r*.64f,y,paint);
            if(plus)c.drawLine(x+r*.38f,y-r*.26f,x+r*.38f,y+r*.26f,paint);
        }
        private void drawHome(Canvas c,float x,float y,float r){
            inkStyle(r*.075f);triangle.reset();
            triangle.moveTo(x-r*.60f,y-r*.04f);triangle.lineTo(x,y-r*.56f);
            triangle.lineTo(x+r*.60f,y-r*.04f);triangle.lineTo(x+r*.44f,y-r*.04f);
            triangle.lineTo(x+r*.44f,y+r*.48f);triangle.lineTo(x+r*.14f,y+r*.48f);
            triangle.lineTo(x+r*.14f,y+r*.12f);triangle.lineTo(x-r*.14f,y+r*.12f);
            triangle.lineTo(x-r*.14f,y+r*.48f);triangle.lineTo(x-r*.44f,y+r*.48f);
            triangle.lineTo(x-r*.44f,y-r*.04f);triangle.close();c.drawPath(triangle,paint);
        }
        private void drawBack(Canvas c,float x,float y,float r){
            inkStyle(r*.075f);triangle.reset();
            triangle.moveTo(x-r*.62f,y-r*.12f);triangle.lineTo(x-r*.16f,y-r*.54f);
            triangle.lineTo(x-r*.16f,y-r*.30f);triangle.lineTo(x+r*.12f,y-r*.30f);
            triangle.cubicTo(x+r*.75f,y-r*.30f,x+r*.76f,y+r*.54f,x+r*.12f,y+r*.54f);
            triangle.lineTo(x-r*.12f,y+r*.54f);triangle.lineTo(x-r*.12f,y+r*.34f);
            triangle.lineTo(x+r*.12f,y+r*.34f);
            triangle.cubicTo(x+r*.47f,y+r*.34f,x+r*.47f,y-r*.10f,x+r*.12f,y-r*.10f);
            triangle.lineTo(x-r*.16f,y-r*.10f);triangle.lineTo(x-r*.16f,y+r*.13f);
            triangle.close();c.drawPath(triangle,paint);
        }
        private void drawMenu(Canvas c,float x,float y,float r){
            inkStyle(r*.08f);
            for(int i=-1;i<=1;i++)c.drawLine(x-r*.51f,y+i*r*.31f,x+r*.51f,y+i*r*.31f,paint);
        }
        private void drawSeek(Canvas c,float x,float y,float r,boolean forward){
            float angle=forward?90:270;
            drawArrow(c,x-r*.30f,y,r*.60f,angle);
            drawArrow(c,x+r*.30f,y,r*.60f,angle);
        }
        private void drawMediaGlyph(Canvas c,float x,float y,float size,int target){
            float h=size*.36f;
            if(target==UP){
                drawArrow(c,x-size*.28f,y,size*.65f,90);inkStyle(size*.046f);
                c.drawRoundRect(x+size*.12f,y-h,x+size*.24f,y+h,size*.035f,size*.035f,paint);
                c.drawRoundRect(x+size*.37f,y-h,x+size*.49f,y+h,size*.035f,size*.035f,paint);
            }else if(target==DOWN){
                inkStyle(size*.052f);c.drawRect(x-h,y-h,x+h,y+h,paint);
            }else{
                boolean next=target==RIGHT;float d=next?1:-1;
                drawArrow(c,x-d*size*.10f,y,size*.79f,next?90:270);inkStyle(size*.046f);
                float bar=x+d*size*.43f;
                c.drawRoundRect(bar-size*.065f,y-h,bar+size*.065f,y+h,size*.035f,size*.035f,paint);
            }
        }

        private int hit(float x,float y){
            computeGeometry();
            int slot=geometry.hitKey(x,y);
            if(slot>=0)return slots[slot];
            switch(geometry.hitWheel(x,y)){
                case 1:return OK;
                case 2:return UP;
                case 3:return DOWN;
                case 4:return LEFT;
                case 5:return RIGHT;
                default:return 0;
            }
        }

        @Override public boolean onTouchEvent(MotionEvent e){
            switch(e.getActionMasked()){
                case MotionEvent.ACTION_DOWN:
                    startX=e.getX();startY=e.getY();
                    startTarget=hit(startX,startY);
                    pressed=startTarget;
                    invalidate();return true;
                case MotionEvent.ACTION_MOVE:
                    if(Math.hypot(e.getX()-startX,e.getY()-startY)>dp(15)){
                        if(pressed!=0){pressed=0;invalidate();}
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    int end=hit(e.getX(),e.getY());
                    int perform=startTarget==end &&
                            Math.hypot(e.getX()-startX,e.getY()-startY)<dp(17)?end:0;
                    pressed=0;startTarget=0;invalidate();
                    if(perform!=0){performClick();onKeySelected(perform);}
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    pressed=0;startTarget=0;invalidate();return true;
            }
            return true;
        }

        @Override public boolean performClick(){super.performClick();return true;}

        private void onKeySelected(int target){
            if(target==BOTTOM_LEFT){if(!busy)showBrowser();return;}
            if(target==STATUS){showSettings();return;}
            if(target==BOTTOM_RIGHT){navigationMode=!navigationMode;invalidate();return;}
            if(target==POWER){command("Application.SetMute",obj("mute","toggle"));return;}
            if(target==VOL_DOWN||target==VOL_UP){command("Application.SetVolume",obj("volume",target==VOL_UP?"increment":"decrement"));return;}
            if(target==OK){command("Input.Select",obj());return;}
            if(target==BOTTOM_MIDDLE){playerCommand("Player.SetSubtitle",obj("subtitle","next","enable",true));return;}
            if(target==REWIND||target==FORWARD){playerCommand("Player.Seek",obj("value",obj("seconds",target==FORWARD?30:-30)));return;}
            if(navigationMode){
                String m=target==UP?"Input.Up":target==DOWN?"Input.Down":target==LEFT?"Input.Left":"Input.Right";
                command(m,obj());return;
            }
            if(target==UP)playerCommand("Player.PlayPause",obj("play","toggle"));
            else if(target==DOWN)playerCommand("Player.Stop",obj());
            else if(target==LEFT||target==RIGHT)skip(target==RIGHT?1:-1);
        }
    }
}
