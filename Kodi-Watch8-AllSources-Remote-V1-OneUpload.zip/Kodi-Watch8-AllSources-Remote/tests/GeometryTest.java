package com.kodiwatch.remote;
public class GeometryTest {
 public static void main(String[] args){
  int cases=0; float minGap=Float.MAX_VALUE;
  for(int w=160;w<=560;w+=10)for(int h=160;h<=560;h+=10)for(float density:new float[]{1,1.5f,2,2.5f,3}){
    float inset=2*density;
    RoundPanelGeometry g=new RoundPanelGeometry(w,h,inset,.65f*density);
    if(Math.abs(g.wheel/(g.screenRadius*.59f)-1.15f)>.00001f)throw new AssertionError("wheel scale");
    if(g.ok>=g.screenRadius*.59f*.47f)throw new AssertionError("OK should shrink");
    if(Math.hypot(g.cx-g.sx,g.cy-g.sy)+g.wheel>g.screenRadius+.001)throw new AssertionError("wheel edge");
    for(int i=0;i<g.x.length;i++){
      double outer=Math.hypot(g.x[i]-g.sx,g.y[i]-g.sy);
      double inner=Math.hypot(g.x[i]-g.cx,g.y[i]-g.cy);
      if(g.r[i]<=0 || Math.abs(outer+g.r[i]-g.screenRadius)>.001 || inner-g.r[i]<g.wheel+g.gap-.001)throw new AssertionError("radial");
      if(g.hitKey(g.x[i],g.y[i])!=i||g.hitWheel(g.x[i],g.y[i])!=0)throw new AssertionError("hit key");
      for(int j=i+1;j<g.x.length;j++){
        float gap=(float)Math.hypot(g.x[i]-g.x[j],g.y[i]-g.y[j])-g.r[i]-g.r[j];
        if(gap<g.gap-.001)throw new AssertionError("collision "+gap);
        minGap=Math.min(minGap,gap);
      }
      // Sample the inside of each button, not only its center.
      for(int a=0;a<360;a+=15){
        float px=g.x[i]+g.r[i]*.99f*(float)Math.cos(Math.toRadians(a));
        float py=g.y[i]+g.r[i]*.99f*(float)Math.sin(Math.toRadians(a));
        if(g.hitKey(px,py)!=i||g.hitWheel(px,py)!=0)throw new AssertionError("key edge");
      }
    }
    float m=(g.wheel+g.ok)/2;
    if(g.hitWheel(g.cx,g.cy)!=1||g.hitWheel(g.cx,g.cy-m)!=2||g.hitWheel(g.cx,g.cy+m)!=3||g.hitWheel(g.cx-m,g.cy)!=4||g.hitWheel(g.cx+m,g.cy)!=5||g.hitKey(g.cx,g.cy)!=-1)throw new AssertionError("D-pad");
    cases++;
  }
  System.out.println("Geometry checks passed: "+cases+" cases; minimum inter-key gap "+minGap+" px");
  for(int d:new int[]{192,200,220,240}){
    RoundPanelGeometry g=new RoundPanelGeometry(d,d,2,.65f);
    float min=Float.MAX_VALUE,max=0;for(float r:g.r){min=Math.min(min,r);max=Math.max(max,r);}
    System.out.printf("%d dp: wheel %.2f, OK %.2f, peripheral %.2f–%.2f dp diameters%n",d,g.wheel*2,g.ok*2,min*2,max*2);
  }
 }
}
